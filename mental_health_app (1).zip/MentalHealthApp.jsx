import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function MentalHealthApp() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-6 text-gray-800 font-sans">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-2">Bienestar Mental</h1>
        <p className="text-lg">Cuida tu mente, vive mejor</p>
      </header>

      <Tabs defaultValue="login" className="max-w-md mx-auto">
        <TabsList className="grid grid-cols-2 bg-white shadow rounded-xl mb-6">
          <TabsTrigger value="login">Iniciar sesión</TabsTrigger>
          <TabsTrigger value="content">Contenido</TabsTrigger>
        </TabsList>

        <TabsContent value="login">
          <Card>
            <CardContent className="p-6">
              <form className="space-y-4">
                <Input type="email" placeholder="Correo electrónico" required />
                <Input type="password" placeholder="Contraseña" required />
                <Button className="w-full">Entrar</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="content">
          <Card>
            <CardContent className="p-6 space-y-6">
              <section>
                <h2 className="text-xl font-semibold mb-2">¿Qué es la salud mental?</h2>
                <p>
                  La salud mental incluye nuestro bienestar emocional, psicológico y social. Afecta cómo pensamos,
                  sentimos y actuamos. También determina cómo manejamos el estrés y tomamos decisiones.
                </p>
              </section>
              <section>
                <h2 className="text-xl font-semibold mb-2">Juegos y ejercicios para el estrés</h2>
                <ul className="list-disc pl-5 space-y-1">
                  <li>🧘 Ejercicio de respiración guiada</li>
                  <li>🎨 Colorear mandalas (modo digital)</li>
                  <li>🎵 Sonidos relajantes (modo play)</li>
                  <li>📝 Diario de gratitud</li>
                </ul>
                <Button className="mt-4">Explorar juegos</Button>
              </section>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
